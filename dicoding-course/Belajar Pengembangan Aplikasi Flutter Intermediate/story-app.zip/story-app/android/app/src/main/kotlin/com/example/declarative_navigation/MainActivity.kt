package com.example.declarative_navigation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
